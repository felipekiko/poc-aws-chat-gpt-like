import json
import boto3
import os
import websocket
import time
import threading

class WebSocketClient:
    def __init__(self, ws_url, apigw_management, connection_id, prompt):
        self.ws_url = ws_url
        self.apigw_management = apigw_management
        self.connection_id = connection_id
        self.prompt = prompt
        self.ws = None
        self.keep_running = True

    def on_message(self, ws, message):
        try:
            # Parse the message to extract the content
            try:
                # If the message is a JSON string, parse it
                message_data = json.loads(message)
                
                # Skip 'end' messages
                if isinstance(message_data, dict) and message_data.get('type') == 'end':
                    return
                    
                if isinstance(message_data, dict):
                    # If it has a 'chunk' field, use it directly
                    if 'chunk' in message_data:
                        response = {
                            'type': 'stream',
                            'chunk': str(message_data['chunk'])
                        }
                    else:
                        # Otherwise, wrap the content in the expected format
                        response = {
                            'type': 'stream',
                            'chunk': str(message_data)
                        }
                else:
                    # If it's not a dict after parsing, use it as the chunk
                    response = {
                        'type': 'stream',
                        'chunk': str(message_data)
                    }
            except (json.JSONDecodeError, TypeError):
                # If it's not valid JSON, use it as a plain string
                response = {
                    'type': 'stream',
                    'chunk': str(message)
                }
            
            # Send the properly formatted message
            self.apigw_management.post_to_connection(
                ConnectionId=self.connection_id,
                Data=json.dumps(response)
            )
        except Exception as e:
            print(f"Error forwarding message: {e}")
            self.keep_running = False

    def on_error(self, ws, error):
        print(f"WebSocket error: {error}")
        self.keep_running = False

    def on_close(self, ws, close_status_code, close_msg):
        print("WebSocket connection closed")
        self.keep_running = False

    def on_open(self, ws):
        print("WebSocket connection opened")
        # Send the initial prompt
        ws.send(json.dumps({
            'action': 'sendPrompt',
            'prompt': self.prompt
        }))

    def run(self):
        # Configure WebSocket with callbacks
        self.ws = websocket.WebSocketApp(
            self.ws_url,
            on_message=self.on_message,
            on_error=self.on_error,
            on_close=self.on_close,
            on_open=self.on_open
        )
        
        # Run WebSocket in a separate thread
        def run_ws():
            self.ws.run_forever()
            
        ws_thread = threading.Thread(target=run_ws)
        ws_thread.daemon = True
        ws_thread.start()
        
        # Keep the connection alive until explicitly closed or an error occurs
        # The WebSocket will be managed by the WebSocketApp's run_forever()
        # and will be closed by the on_close handler when the connection ends
        ws_thread.join()  # Wait for the WebSocket thread to complete

def lambda_handler(event, context):
    try:
        # Get WebSocket URL from environment variable
        ws_url = os.environ.get('PROVIDER_ENDPOINT_URL')
        if not ws_url:
            raise ValueError("PROVIDER_ENDPOINT_URL environment variable is not set")
            
        # Process each record from the event
        for record in event.get('Records', []):
            try:
                msg = json.loads(record['body'])
                connection_id = msg.get('connection_id')
                domain = msg.get('domain')
                stage = msg.get('stage')
                prompt = msg.get('prompt')
                
                if not all([connection_id, domain, stage, prompt]):
                    print("Missing required fields in message")
                    continue
                
                # Initialize API Gateway Management API client
                apigw_management = boto3.client(
                    'apigatewaymanagementapi',
                    endpoint_url=f"https://{domain}/{stage}"
                )
                
                # Create and run WebSocket client
                ws_client = WebSocketClient(ws_url, apigw_management, connection_id, prompt)
                ws_client.run()
                
            except Exception as e:
                print(f"Error processing record: {e}")
                # Try to notify the client of the error
                try:
                    apigw_management.post_to_connection(
                        ConnectionId=connection_id,
                        Data=json.dumps({
                            'type': 'error',
                            'message': f'Error processing request: {str(e)}'
                        })
                    )
                except:
                    pass
                
    except Exception as e:
        print(f"Error in lambda_handler: {e}")
        raise
