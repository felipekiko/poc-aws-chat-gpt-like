import json
import os
import time
import boto3
from websocket import WebSocketApp, WebSocketConnectionClosedException

def lambda_handler(event, context):
    """
    Lambda para consumir o WebSocket externo e repassar mensagens para o API Gateway.
    """
    # Get the provider WebSocket URL from environment variable
    WS_URL = os.environ['PROVIDER_ENDPOINT_URL']

    # Extrai o prompt recebido do frontend
    try:
        if 'body' in event:
            body = json.loads(event['body']) if isinstance(event.get('body'), str) else event.get('body', {})
        else:
            body = event
    except Exception as e:
        print(f"Error parsing event: {e}")
        body = {}

    prompt = body.get('prompt') or body.get('message')
    if not prompt:
        return {
            'statusCode': 400,
            'body': json.dumps({'error': 'No prompt or message provided'})
        }

    request_context = event.get('requestContext', {})
    connection_id = request_context.get('connectionId')
    domain_name = request_context.get('domainName')
    stage = request_context.get('stage')

    if not all([connection_id, domain_name, stage]):
        return {
            'statusCode': 400,
            'body': json.dumps({'error': 'Missing WebSocket connection information'})
        }

    # Configura o cliente do API Gateway Management API
    apigw_management_api = boto3.client(
        'apigatewaymanagementapi',
        endpoint_url=f"https://{domain_name}/{stage}"
    )

    def send_ws_message(message_data):
        try:
            apigw_management_api.post_to_connection(
                ConnectionId=connection_id,
                Data=json.dumps(message_data, ensure_ascii=False)
            )
        except Exception as e:
            print(f"Error sending message to WebSocket: {e}")
            raise

    class WebSocketHandler:
        def __init__(self):
            self.ws = None

        def on_message(self, ws, message):
            try:
                # Check if the message is already a string that looks like JSON
                if isinstance(message, str) and message.strip().startswith('{'):
                    try:
                        # If it's a JSON string, parse it first
                        parsed = json.loads(message)
                        # If it already has the expected format, send as is
                        if 'type' in parsed and 'chunk' in parsed:
                            send_ws_message(parsed)
                        else:
                            # Otherwise, wrap it in the expected format
                            send_ws_message({
                                'type': 'stream',
                                'chunk': message
                            })
                    except json.JSONDecodeError:
                        # If not valid JSON, send as plain text
                        send_ws_message({
                            'type': 'stream',
                            'chunk': message
                        })
                else:
                    # If it's not a string or not JSON, send as is
                    send_ws_message({
                        'type': 'stream',
                        'chunk': str(message)
                    })
            except Exception as e:
                print(f"Error in on_message: {e}")
                ws.close()

        def on_error(self, ws, error):
            print(f"WebSocket error: {error}")
            try:
                send_ws_message({
                    'type': 'error',
                    'message': f'WebSocket error: {str(error)}'
                })
            except:
                pass

        def on_close(self, ws, close_status_code, close_msg):
            print("WebSocket closed")
            try:
                send_ws_message({
                    'type': 'end',
                    'message': 'Connection closed by server'
                })
            except:
                pass

        def on_open(self, ws):
            print("WebSocket opened")
            try:
                ws.send(json.dumps({
                    'action': 'sendPrompt',
                    'prompt': prompt
                }))
            except Exception as e:
                print(f"Error sending initial prompt: {e}")
                ws.close()

    try:
        # Configura e inicia o WebSocket
        ws_handler = WebSocketHandler()
        ws_app = WebSocketApp(
            WS_URL,
            on_open=ws_handler.on_open,
            on_message=ws_handler.on_message,
            on_error=ws_handler.on_error,
            on_close=ws_handler.on_close
        )
        
        # Timeout para evitar que a Lambda fique rodando indefinidamente
        def run_with_timeout():
            ws_app.run_forever()
        
        # Executa o WebSocket por no máximo 25 segundos (para evitar timeout do Lambda)
        import _thread
        _thread.start_new_thread(run_with_timeout, ())
        time.sleep(25)
        ws_app.close()
        
        return {
            'statusCode': 200,
            'body': json.dumps({'message': 'Processing complete'})
        }

    except Exception as e:
        print(f"Error in Lambda handler: {e}")
        try:
            send_ws_message({
                'type': 'error',
                'message': f'Internal server error: {str(e)}'
            })
        except:
            pass
        
        return {
            'statusCode': 500,
            'body': json.dumps({'error': 'Internal server error'})
        }